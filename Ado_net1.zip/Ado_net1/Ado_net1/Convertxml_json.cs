﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Ado_net1
{
    public partial class Convertxml_json : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        public Convertxml_json()
        {
            InitializeComponent();
        }
        DataTable GetStudentDetails()
        {
            dt = new DataTable("Students");

            //#region directive in C#? It lets you specify a block of code that you can expand or collapse when using the outlining feature of the Visual Studio Code Editor. It should be terminated with #endregion.

            #region Students DataTable
            dc = new DataColumn("RollNumber", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("FullName", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Subject", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Fees", typeof(float));
            dt.Columns.Add(dc);
            dc = new DataColumn("DeptId", typeof(int));
            dt.Columns.Add(dc);

            //Populate data in each row
            dr = dt.NewRow();
            dr[0] = 111;
            dr[1] = "Shilpa Vaidya";
            dr[2] = "Dot Net";
            dr[3] = 35000;
            dr[4] = 301;

            //add row to the data table

            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 222;
            dr[1] = "Shreya Rai";
            dr[2] = "Python";
            dr[3] = 20000;
            dr[4] = 302;

            //add row to the data table

            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["RollNumber"] = 333;
            dr["FullName"] = "Yash P";
            dr["Subject"] = "Robotics";
            dr["Fees"] = 37000;
            dr["DeptId"] = 301;

            //add row to the data table

            dt.Rows.Add(dr);

            #endregion

            return dt;


        }
        private void Convertxml_json_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable emp = GetStudentDetails();
            emp.WriteXml("E:\\MyStudentdetails.xml");
        }

        private void btnConverttojson_Click(object sender, EventArgs e)
        {
            DataTable emp = GetStudentDetails();
            string json = JsonConvert.SerializeObject(emp);
            StreamWriter ob = File.CreateText(@"E:\jsonformat.json");
            ob.WriteLine(json);
            ob.Close();
        }
    }
}
