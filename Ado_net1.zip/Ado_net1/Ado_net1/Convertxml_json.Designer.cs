﻿namespace Ado_net1
{
    partial class Convertxml_json
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConverttoxml = new System.Windows.Forms.Button();
            this.btnConverttojson = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnConverttoxml
            // 
            this.btnConverttoxml.Location = new System.Drawing.Point(54, 52);
            this.btnConverttoxml.Name = "btnConverttoxml";
            this.btnConverttoxml.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnConverttoxml.Size = new System.Drawing.Size(186, 45);
            this.btnConverttoxml.TabIndex = 0;
            this.btnConverttoxml.Text = "XML";
            this.btnConverttoxml.UseVisualStyleBackColor = true;
            this.btnConverttoxml.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnConverttojson
            // 
            this.btnConverttojson.Location = new System.Drawing.Point(54, 154);
            this.btnConverttojson.Name = "btnConverttojson";
            this.btnConverttojson.Size = new System.Drawing.Size(186, 45);
            this.btnConverttojson.TabIndex = 1;
            this.btnConverttojson.Text = "JSON";
            this.btnConverttojson.UseVisualStyleBackColor = true;
            this.btnConverttojson.Click += new System.EventHandler(this.btnConverttojson_Click);
            // 
            // Convertxml_json
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnConverttojson);
            this.Controls.Add(this.btnConverttoxml);
            this.Name = "Convertxml_json";
            this.Text = "Convertxml_json";
            this.Load += new System.EventHandler(this.Convertxml_json_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnConverttoxml;
        private System.Windows.Forms.Button btnConverttojson;
    }
}