﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Ado_net1
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;

        DataSet ds;

        DataTable GetStudentDetails()
        {
            dt = new DataTable("Students");

            //#region directive in C#? It lets you specify a block of code that you can expand or collapse when using the outlining feature of the Visual Studio Code Editor. It should be terminated with #endregion.

            #region Students DataTable
            dc = new DataColumn("RollNumber",typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("FullName", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Subject", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Fees", typeof(float));
            dt.Columns.Add(dc);
            dc = new DataColumn("DeptId", typeof(int));
            dt.Columns.Add(dc);

            //Populate data in each row
            dr = dt.NewRow();
            dr[0] = 111;
            dr[1] = "Shilpa Vaidya";
            dr[2] = "Dot Net";
            dr[3] = 35000;
            dr[4] = 301;

            //add row to the data table

            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 222;
            dr[1] = "Shreya Rai";
            dr[2] = "Python";
            dr[3] = 20000;
            dr[4] = 302;

            //add row to the data table

            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["RollNumber"] = 333;
            dr["FullName"] = "Yash P";
            dr["Subject"] = "Robotics";
            dr["Fees"] = 37000;
            dr["DeptId"] = 301;

            //add row to the data table

            dt.Rows.Add(dr);

            #endregion

            return dt;


        }

        DataTable GetDepttDetails()
        {
            dt = new DataTable("Department");

            //#region directive in C#? It lets you specify a block of code that you can expand or collapse when using the outlining feature of the Visual Studio Code Editor. It should be terminated with #endregion.

            #region Department DataTable
            dc = new DataColumn("DeptId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("DepartmentName", typeof(string));
            dt.Columns.Add(dc);

            //Populate data in each row
            dr = dt.NewRow();
            dr[0] = 300;
            dr[1] = "CSE";

            //add row to the data table
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 301;
            dr[1] = "ISE";

            //add row to the data table
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 302;
            dr[1] = "ECE";

            //add row to the data table
            dt.Rows.Add(dr);

            #endregion

            return dt;


        }

        DataSet CreateDataset()
        {
            DataTable stu = GetStudentDetails();
            DataTable dep = GetDepttDetails();

            ds = new DataSet("Mydataset");
            ds.Tables.Add(stu); //like the columns we have index associated here 0 is index
            ds.Tables.Add(dep); //1 index
                                   //ds.Tables[1].Columns[0]
            DataColumn colPrimKey = ds.Tables["Department"].Columns["DeptId"];
            DataColumn colForeignkey = ds.Tables["Students"].Columns["DeptId"];

            DataRelation depsturel = new DataRelation("Student_Department", colPrimKey, colForeignkey);

            ds.Relations.Add(depsturel);

            return ds;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            DataSet dataset = CreateDataset();
            dataGridView1.DataSource = dataset.Tables[0];//or  dataset.Tables["Students"];
            dataGridView2.DataSource = dataset.Tables[1];


        }
    }
}
