﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace Connectionbased
{
    public partial class Delete : Form
    {
        SqlConnection conn;
        public Delete()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Delete_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string id = textBox1.Text;
            string query = "Select * from Player where Pid=" + id;
            SqlCommand cmd = new SqlCommand(query, conn);
            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    pname.Text = reader[1].ToString();
                    pcat.Text = reader[2].ToString();
                    score.Text = reader[3].ToString();
                }
                conn.Close();
                panel1.Visible = true;

            }
            catch (Exception)
            {
                MessageBox.Show("record not found");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string id = textBox1.Text;

                string query1 = "delete  from Player where Pid = " + id;

                MessageBox.Show(query1);
                SqlCommand cd = new SqlCommand(query1, conn);
                conn.Open();
                cd.ExecuteNonQuery();
                MessageBox.Show("DELETED RECORD");
                conn.Close();
                this.Hide();
                Form1 ob = new Form1();
                ob.Visible = true;
            }
            catch (Exception ob1)
            {
                MessageBox.Show("Not able to update the record " + ob1.ToString());
            }
        }
    }
}
