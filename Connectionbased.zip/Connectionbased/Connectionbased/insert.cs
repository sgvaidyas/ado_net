﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Connectionbased
{
    public partial class insert : Form
    {

        SqlConnection conn;

        public insert()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        public void setid()
        {
            try
            {
                string query = "Select  max(Pid)+1 from Player";
                SqlCommand command = new SqlCommand(query,conn);
                conn.Open();
                string id = command.ExecuteScalar().ToString();
                conn.Close();
                textBox4.Text = id;

            }
            catch
            {
                MessageBox.Show("Couldnt connect");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                string playername, category, score,pid;
                playername = textBox1.Text;
                category = textBox2.Text;
                score = textBox3.Text;
                pid = textBox4.Text;          


                string query = "insert into Player values("+pid+",'"+playername+"','" + category + "'," +score + ")";
                MessageBox.Show(query);
                conn.Open();
                SqlCommand cmd= new SqlCommand(query,conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("INSERTED SUCCESSFULLY");
                conn.Close();

                this.Close();
                Form1 ob = new Form1();
                ob.Show();
            }
            catch(Exception ob)
            {
                MessageBox.Show("Data couldnt be inserted");
            }
        }

        private void insert_Load(object sender, EventArgs e)
        {
            setid();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}
