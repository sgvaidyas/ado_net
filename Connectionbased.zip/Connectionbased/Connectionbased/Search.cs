﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Connectionbased
{
    public partial class Search : Form
    {
        SqlConnection conn;
        public Search()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = textBox1.Text;
            string query = "Select * from Player where Pid=" + id;
            MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if(reader.HasRows)
                {
                    reader.Read();
                    pname.Text = reader[1].ToString();
                    pcat.Text = reader[2].ToString();
                    score.Text = reader[3].ToString();
                    conn.Close();

                }
                else
                {
                    MessageBox.Show("RECORD NOT FOUND");
                    conn.Close();
                }
                panel1.Visible = true;

            }
            catch(Exception e1)
            {
                MessageBox.Show("record not found" + e1);
            }

        }

        private void Search_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
