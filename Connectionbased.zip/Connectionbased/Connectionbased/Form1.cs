﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Connectionbased
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            insert ob = new insert();
            ob.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Search ob = new Search();
            ob.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Update ob = new Update();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Delete ob = new Delete();
            ob.Show();
            this.Hide();
        }
    }
}
