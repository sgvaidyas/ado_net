﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Connectionbased
{
    public partial class Update : Form
    {
        SqlConnection conn;
        public Update()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Update_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = textBox1.Text;
            string query = "Select * from Player where Pid=" + id;
            SqlCommand cmd = new SqlCommand(query, conn);
            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    panel1.Visible = true;
                    conn.Close();
                   
                }
                else
                {
                    MessageBox.Show("The PID you are trying to update doesnt exist");
                    conn.Close();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("record not found");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string id = textBox1.Text;
                string pname = textBox2.Text;
                string pcat = textBox3.Text;
                string score = textBox4.Text;

                string query1 = "update Player set PlayerName = '" + pname + "', GameCategory = '" + pcat + "', Score = " + score + "  where Pid = " + id;

                MessageBox.Show(query1);
                SqlCommand cd = new SqlCommand(query1, conn);
                conn.Open();
                cd.ExecuteNonQuery();
                MessageBox.Show("Updated the data");
                conn.Close();
            }
            catch (Exception ob1)
            {
                MessageBox.Show("Not able to update the record "+ ob1.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form1 ob = new Form1();
            ob.Visible = true;
        }
    }
}
